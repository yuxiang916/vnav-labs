Header header
PolynomialSegment[] segments
